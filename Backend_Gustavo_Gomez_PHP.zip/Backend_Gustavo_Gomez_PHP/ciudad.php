<?php
  require('./filtro.php'); 
  $getData = leerDatos(); 
  obtnciudad($getData) 
 ?>
